
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://nfhhpkfpfvztdwzqclrw.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5maGhwa2ZwZnZ6dGR3enFjbHJ3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY5MDQ1NTgsImV4cCI6MjA4MjQ4MDU1OH0.xjmFNyVkdiH7gZ5CWK8ckEn2HgIDsAXtOQjhzqnvvbo';

export const supabase = createClient(supabaseUrl, supabaseKey);
