
export enum TableStatus {
  AVAILABLE = 'DISPONIBLE',
  OCCUPIED = 'OCUPADA',
  BILLING = 'CUENTA'
}

export interface InventoryItem {
  id: string; // uuid
  name: string;
  category: string;
  purchase_price: number;
  sale_price: number;
  units: number;
  min_stock: number;
  created_at?: string;
}

export type Product = InventoryItem;

export interface Expense {
  id?: string; // uuid
  amount: number;
  description: string;
  category: string;
  created_at?: string;
  timestamp?: Date; // Frontend helper
}

export interface FinanceDTO {
  id: string;
  date: string;
  initial_amount: number;
  tips: number;
  sales: number;
  created_at?: string;
}

export interface TableDTO {
  id: number;
  table_number: number;
  is_occupied: boolean;
  comanda: any; // jsonb
  updated_at?: string;
}

// Frontend Types
export interface Subject {
  id: string;
  name: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  name: string;
  price: number;
  quantity: number;
  subjectId: string;
  isPromotion?: boolean;
}

export interface Table {
  id: number;
  status: TableStatus;
  subjects: Subject[];
  order: OrderItem[];
  startTime?: Date;
}

export interface DailyFinance {
  openingCash: number;
  expenses: Expense[];
  date: string;
  totalTips: number;
}

export interface PromotionItem {
  productId: string;
  quantity: number;
}

export interface Promotion {
  id: string;
  name: string;
  price: number;
  items: PromotionItem[];
}
