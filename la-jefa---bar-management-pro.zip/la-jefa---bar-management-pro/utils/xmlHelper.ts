
import { Product, DailyFinance } from '../types';

export const generateFullReportXML = (
  finance: DailyFinance,
  sales: number,
  expenses: number,
  balance: number,
  inventory: Product[]
): string => {
  const today = new Date();
  const fechaStr = today.toLocaleDateString('es-ES').replace(/\//g, '-');

  const maxRows = Math.max(finance.expenses.length, inventory.length, 1);

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += `<ReporteCierre>\n`;

  for (let i = 0; i < maxRows; i++) {
    const expense = finance.expenses[i];
    const product = inventory[i];

    const formatTime = (ts: any) => {
      if (!ts) return '';
      try {
        const date = (typeof ts === 'string' || typeof ts === 'number') ? new Date(ts) : ts;
        if (isNaN(date.getTime())) return '';
        return date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
      } catch (e) {
        return '';
      }
    };

    xml += '  <Fila>\n';

    // A: Fecha, B: FondoInicial, C: VentasNetas, D: TotalPropinas, E: TotalGastos, F: MontoFinalEnCaja
    if (i === 0) {
      xml += `    <Fecha>${fechaStr}</Fecha>\n`;
      xml += `    <FondoInicial>${finance.openingCash}</FondoInicial>\n`;
      xml += `    <VentasNetas>${sales}</VentasNetas>\n`;
      xml += `    <TotalPropinas>${finance.totalTips}</TotalPropinas>\n`;
      xml += `    <TotalGastos>${expenses}</TotalGastos>\n`;
      xml += `    <MontoFinalEnCaja>${balance}</MontoFinalEnCaja>\n`;
    } else {
      xml += `    <Fecha></Fecha>\n`;
      xml += `    <FondoInicial></FondoInicial>\n`;
      xml += `    <VentasNetas></VentasNetas>\n`;
      xml += `    <TotalPropinas></TotalPropinas>\n`;
      xml += `    <TotalGastos></TotalGastos>\n`;
      xml += `    <MontoFinalEnCaja></MontoFinalEnCaja>\n`;
    }

    // G: Concepto, H: Monto, I: Categoria, J: Hora
    xml += `    <ConceptoGasto>${expense ? expense.description : ''}</ConceptoGasto>\n`;
    xml += `    <MontoGasto>${expense ? expense.amount : ''}</MontoGasto>\n`;
    xml += `    <CategoriaGasto>${expense ? expense.category : ''}</CategoriaGasto>\n`;
    xml += `    <HoraGasto>${formatTime(expense?.timestamp)}</HoraGasto>\n`;

    // K: Nombre, L: Categoria2, M: StockActual, N: ValorVentaTotal, O: ValorCostoTotal
    xml += `    <NombreProducto>${product ? product.name : ''}</NombreProducto>\n`;
    xml += `    <CategoriaProducto>${product ? product.category : ''}</CategoriaProducto>\n`;
    xml += `    <StockActual>${product ? product.units : ''}</StockActual>\n`;
    xml += `    <ValorVentaTotal>${product ? (product.units * product.sale_price).toFixed(2) : ''}</ValorVentaTotal>\n`;
    xml += `    <ValorCostoTotal>${product ? (product.units * product.purchase_price).toFixed(2) : ''}</ValorCostoTotal>\n`;

    xml += '  </Fila>\n';
  }

  xml += '</ReporteCierre>';
  return xml;
};
