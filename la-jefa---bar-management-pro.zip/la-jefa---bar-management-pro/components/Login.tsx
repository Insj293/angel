
import React, { useState } from 'react';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // RUTA LOCAL: Asegúrate de tener la carpeta 'assets' con el archivo 'logo.png'
  const LOGO_URL = "./assets/logo.png";

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === 'admin') {
      onLogin();
    } else {
      setError('Credenciales incorrectas');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black p-6">
      <div className="w-full max-w-md bg-[#111] border border-gray-800 p-10 rounded-3xl shadow-2xl relative overflow-hidden animate-fadeIn">
        <div className="absolute top-0 left-0 w-full h-1 bg-amber-500"></div>
        
        <div className="flex flex-col items-center mb-8">
           <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center mb-6 shadow-xl shadow-amber-500/10 overflow-hidden p-4 border border-gray-800/50">
             <img 
               src={LOGO_URL} 
               alt="La Jefa Logo" 
               className="w-full h-full object-contain scale-110"
               onError={(e) => {
                 const target = e.target as HTMLImageElement;
                 target.style.display = 'none';
                 if (target.parentElement) {
                    target.parentElement.innerHTML = '<span class="text-4xl font-cinzel font-bold text-black">LJ</span>';
                    target.parentElement.classList.add('bg-amber-500');
                    target.parentElement.classList.remove('bg-white');
                 }
               }}
             />
           </div>
           <h1 className="text-3xl font-cinzel font-bold text-amber-500 uppercase tracking-[0.2em]">La Jefa</h1>
           <p className="text-gray-500 text-sm mt-2 font-medium">Panel Administrativo</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="text-[10px] text-gray-500 uppercase font-bold block mb-2 tracking-widest">Usuario</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-black border border-gray-800 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-amber-500 transition-all placeholder-gray-700 font-medium"
              placeholder="admin"
              required
            />
          </div>
          <div>
            <label className="text-[10px] text-gray-500 uppercase font-bold block mb-2 tracking-widest">Contraseña</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-black border border-gray-800 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-amber-500 transition-all placeholder-gray-700 font-medium"
              placeholder="••••••••"
              required
            />
          </div>

          {error && <p className="text-red-500 text-xs font-bold text-center animate-pulse">{error}</p>}

          <button
            type="submit"
            className="w-full bg-amber-500 text-black font-black py-4 rounded-2xl hover:bg-amber-400 transition-all uppercase tracking-widest shadow-lg shadow-amber-500/10 active:scale-95"
          >
            Entrar al Sistema
          </button>
        </form>
        
        <div className="mt-8 text-center">
           <p className="text-gray-600 text-[10px] font-bold uppercase tracking-tighter">© 2024 La Jefa • Almacenamiento Local Seguro</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
