
import React, { useState, useEffect } from 'react';
import { DailyFinance, Expense } from '../types';

interface FinanceViewProps {
  finance: DailyFinance;
  sales: number;
  onUpdateOpeningCash: (amount: number) => void;
  onAddExpense: (expense: Omit<Expense, 'id' | 'timestamp'>) => void;
}

const FinanceView: React.FC<FinanceViewProps> = ({ finance, sales, onUpdateOpeningCash, onAddExpense }) => {
  const [isOpeningCashSet, setIsOpeningCashSet] = useState(finance.openingCash > 0);
  const [tempOpening, setTempOpening] = useState(finance.openingCash);
  const [expenseForm, setExpenseForm] = useState({ description: '', amount: 0, category: 'Operativo' });

  // Sincronizar el estado local cuando finance.openingCash cambia (útil al reiniciar caja)
  useEffect(() => {
    setIsOpeningCashSet(finance.openingCash > 0);
    setTempOpening(finance.openingCash);
  }, [finance.openingCash]);

  const totalExpenses = finance.expenses.reduce((acc, e) => acc + e.amount, 0);
  const currentBalance = finance.openingCash + sales + finance.totalTips - totalExpenses;

  const handleSubmitExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (expenseForm.description && expenseForm.amount > 0) {
      onAddExpense(expenseForm);
      setExpenseForm({ description: '', amount: 0, category: 'Operativo' });
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto">
      {/* Resumen Financiero Superior */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <div className="bg-[#111] border border-gray-800 p-6 rounded-2xl shadow-lg flex flex-col justify-between h-[160px]">
          <div>
            <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest mb-2">Fondo Inicial</p>
            <div className="h-12 flex items-center">
              {isOpeningCashSet ? (
                  <h3 className="text-2xl font-mono font-bold text-white tracking-tighter">${finance.openingCash.toLocaleString()}</h3>
              ) : (
                  <div className="flex w-full items-stretch gap-2 bg-black border border-gray-800 rounded-xl p-1">
                    <input 
                      type="number" 
                      className="bg-transparent px-2 py-1 text-sm flex-1 font-mono text-white outline-none min-w-0"
                      placeholder="Monto"
                      value={tempOpening || ''}
                      onChange={(e) => setTempOpening(parseFloat(e.target.value) || 0)}
                    />
                    <button 
                      onClick={() => {
                          onUpdateOpeningCash(tempOpening);
                          setIsOpeningCashSet(true);
                      }}
                      className="bg-amber-500 text-black px-4 rounded-lg text-[10px] font-black uppercase hover:bg-amber-400 transition-colors whitespace-nowrap shadow-lg shadow-amber-500/20"
                    >
                      Fijar
                    </button>
                  </div>
              )}
            </div>
          </div>
          <button onClick={() => setIsOpeningCashSet(false)} className="text-[9px] text-gray-600 hover:text-amber-500 uppercase font-black transition-colors text-left flex items-center gap-1">
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            {isOpeningCashSet ? 'Reajustar fondo' : 'Cancelar edición'}
          </button>
        </div>

        <div className="bg-[#111] border border-gray-800 p-6 rounded-2xl shadow-lg h-[160px]">
           <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest mb-1">Ventas Brutas</p>
           <h3 className="text-2xl font-mono font-bold text-green-500 tracking-tighter">+${sales.toLocaleString()}</h3>
           <p className="text-[9px] text-gray-600 font-bold uppercase mt-2">Ingresos por consumo</p>
        </div>

        <div className="bg-[#111] border border-gray-800 p-6 rounded-2xl shadow-lg h-[160px]">
           <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest mb-1">Propinas Totales</p>
           <h3 className="text-2xl font-mono font-bold text-amber-500 tracking-tighter">+${finance.totalTips.toLocaleString()}</h3>
           <p className="text-[9px] text-gray-600 font-bold uppercase mt-2">Extra en caja</p>
        </div>

        <div className="bg-[#111] border border-gray-800 p-6 rounded-2xl shadow-lg h-[160px]">
           <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest mb-1">Gastos de Hoy</p>
           <h3 className="text-2xl font-mono font-bold text-red-500 tracking-tighter">-${totalExpenses.toLocaleString()}</h3>
           <p className="text-[9px] text-gray-600 font-bold uppercase mt-2">Salidas registradas</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
         {/* Formulario de Gastos */}
         <div className="bg-[#111] border border-gray-800 rounded-2xl p-6 shadow-xl">
            <h2 className="text-xl font-cinzel font-bold text-amber-500 mb-6 uppercase tracking-widest flex items-center gap-2">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
               </svg>
               Registrar Gasto
            </h2>
            <form onSubmit={handleSubmitExpense} className="space-y-4">
               <div>
                  <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Concepto / Proveedor</label>
                  <input 
                    required
                    type="text" 
                    value={expenseForm.description}
                    onChange={e => setExpenseForm(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:border-amber-500 transition-all outline-none"
                    placeholder="Ej. Cervecería Modelo - Pedido Semanal"
                  />
               </div>
               <div className="grid grid-cols-2 gap-4">
                  <div>
                     <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Monto ($)</label>
                     <input 
                       required
                       type="number" 
                       value={expenseForm.amount || ''}
                       onChange={e => setExpenseForm(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                       className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:border-amber-500 transition-all outline-none font-mono"
                     />
                  </div>
                  <div>
                     <label className="text-xs text-gray-500 uppercase font-bold block mb-1">Categoría</label>
                     <select 
                       value={expenseForm.category}
                       onChange={e => setExpenseForm(prev => ({ ...prev, category: e.target.value }))}
                       className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:border-amber-500 transition-all outline-none"
                     >
                        <option>Operativo</option>
                        <option>Inventario</option>
                        <option>Servicios</option>
                        <option>Mantenimiento</option>
                        <option>Otros</option>
                     </select>
                  </div>
               </div>
               <button 
                 type="submit"
                 className="w-full bg-red-600 text-white py-4 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-red-500 active:scale-[0.98] transition-all shadow-lg shadow-red-600/10"
               >
                  Agregar Gasto a Cuenta
               </button>
            </form>
         </div>

         {/* Historial y Balance Final */}
         <div className="bg-[#111] border border-gray-800 rounded-2xl p-6 flex flex-col shadow-xl">
            <h2 className="text-xl font-cinzel font-bold text-amber-500 mb-6 uppercase tracking-widest flex items-center gap-2">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
               </svg>
               Historial de Egresos
            </h2>
            <div className="flex-1 space-y-3 overflow-y-auto max-h-[250px] pr-2 custom-scrollbar">
               {finance.expenses.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-gray-600">
                     <svg className="w-12 h-12 mb-2 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                     <p className="text-xs font-bold uppercase tracking-tighter text-center">Sin gastos registrados hoy</p>
                  </div>
               ) : (
                  finance.expenses.map(exp => (
                    <div key={exp.id} className="flex justify-between items-center p-4 bg-[#1a1a1a] rounded-xl border border-gray-800 hover:border-red-500/30 transition-colors">
                       <div>
                          <p className="font-bold text-sm text-gray-200">{exp.description}</p>
                          <p className="text-[9px] text-gray-500 uppercase font-black">{exp.category} • {new Date(exp.timestamp).toLocaleTimeString()}</p>
                       </div>
                       <span className="font-mono text-red-500 font-bold">-${exp.amount.toLocaleString()}</span>
                    </div>
                  ))
               )}
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-800">
               <div className="bg-black/60 p-5 rounded-2xl border border-amber-500/20 shadow-inner">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-gray-500 font-black uppercase text-[10px] tracking-[0.2em]">Balance Final Esperado (Caja)</span>
                    <span className="bg-amber-500 text-black text-[8px] font-black px-1.5 py-0.5 rounded uppercase">Arqueo</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-[9px] text-gray-600 font-bold uppercase w-1/2">Suma de fondo + ventas + propinas - gastos</p>
                    <span className="text-3xl font-mono font-bold text-amber-500 tracking-tighter">${currentBalance.toLocaleString()}</span>
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default FinanceView;
