
import React, { useState } from 'react';
import { Product } from '../types';

interface InventoryProps {
  inventory: Product[];
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
}

const InventoryManager: React.FC<InventoryProps> = ({ inventory, onUpdateProduct, onDeleteProduct }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempProduct, setTempProduct] = useState<Product | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const startEdit = (p: Product) => {
    setEditingId(p.id);
    setTempProduct({ ...p });
  };

  const handleSave = () => {
    if (tempProduct) {
      onUpdateProduct(tempProduct);
      setEditingId(null);
    }
  };

  const handleQuickRestock = (product: Product) => {
    const amount = prompt(`¿Cuántas unidades de ${product.name} recibiste?`, "24");
    if (amount && !isNaN(parseInt(amount))) {
      onUpdateProduct({ ...product, units: product.units + parseInt(amount) });
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="bg-[#111] border border-gray-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[900px]">
            <thead>
              <tr className="bg-[#1a1a1a] text-gray-500 uppercase text-[10px] font-bold tracking-widest border-b border-gray-800">
                <th className="px-6 py-4">Producto</th>
                <th className="px-6 py-4">Categoría</th>
                <th className="px-6 py-4">Costo Bruto</th>
                <th className="px-6 py-4">Precio Venta</th>
                <th className="px-6 py-4">Margen</th>
                <th className="px-6 py-4">Unidades</th>
                <th className="px-6 py-4 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {inventory.map(item => (
                <tr key={item.id} className="hover:bg-[#151515] transition-colors group">
                  <td className="px-6 py-4">
                    {editingId === item.id ? (
                      <input type="text" value={tempProduct?.name}
                        onChange={e => setTempProduct(p => p ? ({ ...p, name: e.target.value }) : null)}
                        className="bg-black border border-gray-700 rounded px-2 py-1 w-full text-sm font-bold text-amber-500" />
                    ) : (
                      <p className="font-bold text-gray-200 text-sm">{item.name}</p>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === item.id ? (
                      <input type="text" value={tempProduct?.category}
                        onChange={e => setTempProduct(p => p ? ({ ...p, category: e.target.value }) : null)}
                        className="bg-black border border-gray-700 rounded px-2 py-1 w-full text-[10px] uppercase font-black" />
                    ) : (
                      <span className="text-[10px] text-gray-500 uppercase font-black bg-gray-800/50 px-2 py-1 rounded-md">{item.category}</span>
                    )}
                  </td>
                  <td className="px-6 py-4 font-mono text-sm text-red-400">
                    {editingId === item.id ? (
                      <input type="number" value={tempProduct?.purchase_price}
                        onChange={e => setTempProduct(p => p ? ({ ...p, purchase_price: parseFloat(e.target.value) || 0 }) : null)}
                        className="bg-black border border-gray-700 rounded px-2 py-1 w-20 text-sm" />
                    ) : `$${item.purchase_price}`}
                  </td>
                  <td className="px-6 py-4 font-mono text-sm text-green-500">
                    {editingId === item.id ? (
                      <input type="number" value={tempProduct?.sale_price}
                        onChange={e => setTempProduct(p => p ? ({ ...p, sale_price: parseFloat(e.target.value) || 0 }) : null)}
                        className="bg-black border border-gray-700 rounded px-2 py-1 w-20 text-sm" />
                    ) : `$${item.sale_price}`}
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-amber-500 text-[10px] font-black bg-amber-500/10 px-2 py-1 rounded">
                      {item.sale_price > 0 ? (((item.sale_price - item.purchase_price) / item.sale_price) * 100).toFixed(0) : 0}%
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {editingId === item.id ? (
                        <input type="number" value={tempProduct?.units}
                          onChange={e => setTempProduct(p => p ? ({ ...p, units: parseInt(e.target.value) || 0 }) : null)}
                          className="bg-black border border-gray-700 rounded px-2 py-1 w-20 text-sm" />
                      ) : (
                        <div className="flex flex-col">
                          <span className={`font-mono text-sm ${item.units <= item.min_stock ? 'text-red-500 font-bold' : 'text-gray-300'}`}>
                            {item.units} uds
                          </span>
                          <span className="text-[9px] text-gray-600 font-bold">Total Venta: ${(item.units * item.sale_price).toLocaleString()}</span>
                          {item.units <= item.min_stock && <span className="text-[8px] text-red-600 font-black uppercase animate-pulse mt-0.5">Reestock</span>}
                        </div>
                      )}
                      <button onClick={() => handleQuickRestock(item)} className="p-1 bg-green-600/20 text-green-500 rounded hover:bg-green-600 hover:text-white transition-all">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeWidth="2" strokeLinecap="round" /></svg>
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-3">
                      {editingId === item.id ? (
                        <button onClick={handleSave} className="text-green-500 font-black text-[10px] uppercase tracking-widest hover:text-green-400">Guardar</button>
                      ) : (
                        <>
                          {confirmDeleteId === item.id ? (
                            <div className="flex items-center gap-2">
                              <button onClick={() => { onDeleteProduct(item.id); setConfirmDeleteId(null); }} className="bg-red-600 text-white px-2 py-1 rounded text-[9px] font-black uppercase">Borrar</button>
                              <button onClick={() => setConfirmDeleteId(null)} className="text-gray-500 text-[9px] uppercase font-bold">No</button>
                            </div>
                          ) : (
                            <>
                              <button onClick={() => startEdit(item)} className="text-amber-500 font-bold text-[10px] uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Editar</button>
                              <button onClick={() => setConfirmDeleteId(item.id)} className="text-gray-600 hover:text-red-500 transition-colors p-1">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                              </button>
                            </>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default InventoryManager;
