
import React, { useState } from 'react';
import { Promotion, Product, PromotionItem } from '../types';

interface PromotionsManagerProps {
  promotions: Promotion[];
  inventory: Product[];
  onUpdatePromotion: (promo: Promotion) => void;
  onDeletePromotion: (id: string) => void;
}

const PromotionsManager: React.FC<PromotionsManagerProps> = ({ promotions, inventory, onUpdatePromotion, onDeletePromotion }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newPromo, setNewPromo] = useState<Omit<Promotion, 'id'>>({
    name: '',
    price: 0,
    items: []
  });

  const handleAddItemToPromo = (productId: string) => {
    const exists = newPromo.items.find(i => i.productId === productId);
    if (exists) {
      setNewPromo({
        ...newPromo,
        items: newPromo.items.map(i => i.productId === productId ? { ...i, quantity: i.quantity + 1 } : i)
      });
    } else {
      setNewPromo({
        ...newPromo,
        items: [...newPromo.items, { productId, quantity: 1 }]
      });
    }
  };

  const handleSave = () => {
    if (!newPromo.name || newPromo.items.length === 0) return;
    onUpdatePromotion({
      ...newPromo,
      id: Date.now().toString()
    });
    setNewPromo({ name: '', price: 0, items: [] });
    setIsAdding(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-cinzel font-bold text-amber-500 uppercase tracking-widest">Gestión de Promociones</h2>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-amber-500 text-black px-4 py-2 rounded-xl font-black text-[10px] uppercase hover:bg-amber-400 transition-all"
        >
          + Crear Promoción
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {promotions.map(promo => (
          <div key={promo.id} className="bg-[#111] border border-gray-800 p-6 rounded-2xl relative group overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
               <button onClick={() => onDeletePromotion(promo.id)} className="text-gray-500 hover:text-red-500">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
               </button>
            </div>
            <h3 className="text-lg font-bold text-gray-100 mb-1">{promo.name}</h3>
            <p className="text-2xl font-mono font-bold text-green-500 mb-4">${promo.price} <span className="text-[10px] text-gray-500">MXN</span></p>
            
            <div className="space-y-2 border-t border-gray-800 pt-4">
              <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest">Componentes:</p>
              {promo.items.map((item, idx) => {
                const prod = inventory.find(p => p.id === item.productId);
                return (
                  <div key={idx} className="flex justify-between text-xs">
                    <span className="text-gray-400">{prod?.name || 'Producto Eliminado'}</span>
                    <span className="text-amber-500 font-bold">{item.quantity} uds</span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {isAdding && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <div className="bg-[#111] border border-gray-800 p-8 rounded-3xl max-w-2xl w-full shadow-2xl flex flex-col md:flex-row gap-8">
            <div className="flex-1 space-y-4">
               <h2 className="text-xl font-cinzel font-bold text-amber-500 mb-4 uppercase tracking-widest">Nueva Promoción</h2>
               <input 
                 type="text" placeholder="Nombre (ej. Combo Amigos)" 
                 className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none"
                 value={newPromo.name} onChange={e => setNewPromo({...newPromo, name: e.target.value})}
               />
               <input 
                 type="number" placeholder="Precio de Venta (MXN)" 
                 className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none font-mono"
                 value={newPromo.price || ''} onChange={e => setNewPromo({...newPromo, price: parseFloat(e.target.value) || 0})}
               />
               
               <div className="bg-black/50 p-4 rounded-xl border border-gray-800 max-h-[200px] overflow-y-auto">
                 <p className="text-[10px] text-gray-500 font-black uppercase mb-2">Items Seleccionados:</p>
                 {newPromo.items.length === 0 && <p className="text-gray-600 text-xs italic">Ningún producto añadido...</p>}
                 {newPromo.items.map((item, idx) => {
                    const prod = inventory.find(p => p.id === item.productId);
                    return (
                      <div key={idx} className="flex justify-between items-center py-1 border-b border-gray-900">
                        <span className="text-xs">{prod?.name}</span>
                        <div className="flex items-center gap-2">
                           <button onClick={() => {
                             const updated = [...newPromo.items];
                             if (updated[idx].quantity > 1) updated[idx].quantity--;
                             else updated.splice(idx, 1);
                             setNewPromo({...newPromo, items: updated});
                           }} className="text-red-500 font-bold px-2">-</button>
                           <span className="text-xs font-mono">{item.quantity}</span>
                           <button onClick={() => {
                             const updated = [...newPromo.items];
                             updated[idx].quantity++;
                             setNewPromo({...newPromo, items: updated});
                           }} className="text-green-500 font-bold px-2">+</button>
                        </div>
                      </div>
                    );
                 })}
               </div>

               <div className="flex gap-2 pt-4">
                  <button onClick={handleSave} className="flex-1 bg-amber-500 text-black font-black py-3 rounded-xl uppercase text-[10px] tracking-widest">Crear Promo</button>
                  <button onClick={() => setIsAdding(false)} className="px-6 text-gray-500 text-[10px] font-bold uppercase">Cerrar</button>
               </div>
            </div>

            <div className="w-full md:w-64 border-l border-gray-800 pl-0 md:pl-8 flex flex-col">
               <p className="text-[10px] text-gray-500 font-black uppercase mb-4 tracking-widest">Lista de Inventario</p>
               <div className="flex-1 overflow-y-auto max-h-[300px] space-y-2 pr-2 custom-scrollbar">
                  {inventory.map(p => (
                    <button 
                      key={p.id} 
                      onClick={() => handleAddItemToPromo(p.id)}
                      className="w-full text-left p-2 bg-black border border-gray-800 rounded-lg hover:border-amber-500 transition-colors text-xs"
                    >
                      {p.name}
                    </button>
                  ))}
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PromotionsManager;
