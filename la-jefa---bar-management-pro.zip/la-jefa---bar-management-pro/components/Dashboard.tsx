
import React from 'react';
import { Product } from '../types';

interface DashboardProps {
  inventory: Product[];
  sales: number;
  expenses: number;
  lowStockCount: number;
  tablesOccupied: number;
  tips: number;
}

const Dashboard: React.FC<DashboardProps> = ({ inventory, sales, expenses, lowStockCount, tablesOccupied, tips }) => {
  const lowStockItems = inventory.filter(p => p.units <= p.min_stock);

  return (
    <div className="space-y-6 md:space-y-8 animate-fadeIn">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 md:gap-4">
        <StatCard title="Ventas" value={`$${sales.toLocaleString()} MXN`} icon="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" color="text-green-500" />
        <StatCard title="Propinas" value={`$${tips.toLocaleString()} MXN`} icon="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" color="text-amber-500" />
        <StatCard title="Gastos" value={`$${expenses.toLocaleString()} MXN`} icon="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" color="text-red-500" />
        <StatCard title="Mesas" value={tablesOccupied.toString()} icon="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" color="text-blue-500" />
        <StatCard title="Alertas" value={lowStockCount.toString()} icon="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" color="text-orange-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        <div className="bg-[#111] border border-gray-800 rounded-2xl p-4 md:p-6">
          <h2 className="text-lg md:text-xl font-cinzel font-bold text-amber-500 mb-6 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            Reestock Necesario
          </h2>
          {lowStockItems.length === 0 ? (
            <p className="text-gray-500 text-center py-10 text-sm italic">Inventario al día.</p>
          ) : (
            <div className="space-y-3">
              {lowStockItems.map(item => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-[#1a1a1a] border border-red-500/20 rounded-xl">
                  <div>
                    <h3 className="font-bold text-gray-200 text-sm">{item.name}</h3>
                    <p className="text-[10px] text-gray-500">{item.category}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-red-500 font-bold block text-sm">{item.units} / {item.min_stock} uds</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-[#111] border border-gray-800 rounded-2xl p-4 md:p-6">
          <h2 className="text-lg md:text-xl font-cinzel font-bold text-amber-500 mb-6 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            Resumen de Caja
          </h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-gray-800 text-sm">
              <span className="text-gray-400">Total Propinas</span>
              <span className="text-amber-500 font-mono">+${tips.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-800 text-sm">
              <span className="text-gray-400">Ventas Brutas</span>
              <span className="text-green-500 font-mono">${sales.toLocaleString()}</span>
            </div>
            <div className="bg-[#1a1a1a] p-4 md:p-6 rounded-2xl text-center mt-2 border border-gray-800">
              <p className="text-gray-500 text-[10px] mb-1 uppercase tracking-widest font-bold">Saldo Neto (Ventas - Gastos)</p>
              <h3 className={`text-2xl md:text-4xl font-mono font-bold ${sales - expenses >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                ${(sales - expenses).toLocaleString()} MXN
              </h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, color }: any) => (
  <div className="bg-[#111] border border-gray-800 p-4 rounded-2xl hover:border-gray-700 transition-all">
    <div className="flex items-center justify-between mb-2">
      <div className={`p-2 rounded-lg bg-gray-900 ${color}`}>
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={icon} />
        </svg>
      </div>
    </div>
    <p className="text-gray-500 text-[10px] font-semibold mb-1 uppercase tracking-tighter truncate">{title}</p>
    <h3 className="text-lg font-mono font-bold truncate">{value}</h3>
  </div>
);

export default Dashboard;
