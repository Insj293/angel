
import React, { useState } from 'react';
import { Table, TableStatus, Product, OrderItem, Promotion } from '../types';

interface TablesGridProps {
  tables: Table[];
  inventory: Product[];
  promotions: Promotion[];
  onUpdateTable: (table: Table) => void;
  onCloseTable: (id: number, subtotal: number, tip: number, subjectId?: string) => void;
  onAddItem: (tableId: number, item: Product | Promotion) => void;
}

const TablesGrid: React.FC<TablesGridProps> = ({ tables, inventory, promotions, onUpdateTable, onCloseTable, onAddItem }) => {
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [orderTab, setOrderTab] = useState<'products' | 'promos'>('products');

  const addSubject = () => {
    if (!selectedTable) return;
    const newId = Date.now().toString();
    const newSubject = { id: newId, name: `Sujeto ${selectedTable.subjects.length + 1}` };
    const updated = { ...selectedTable, subjects: [...selectedTable.subjects, newSubject] };
    setSelectedTable(updated);
    onUpdateTable(updated);
  };

  const handleAddItemToOrder = (item: Product | Promotion) => {
    if (!selectedTable) return;
    onAddItem(selectedTable.id, item);

    const currentTable = tables.find(t => t.id === selectedTable.id);
    if (currentTable) {
      setSelectedTable({ ...currentTable });
    }
  };

  const assignItemToSubject = (itemId: string, subjectId: string) => {
    if (!selectedTable) return;
    const updatedOrder = selectedTable.order.map(item =>
      item.id === itemId ? { ...item, subjectId } : item
    );
    const updated = { ...selectedTable, order: updatedOrder };
    setSelectedTable(updated);
    onUpdateTable(updated);
  };

  const calculateTotal = (order: OrderItem[], subjectId?: string) => {
    const items = subjectId ? order.filter(i => i.subjectId === subjectId) : order;
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const TipPaymentBlock = ({ subtotal, label, onConfirm }: { subtotal: number, label: string, onConfirm: (tip: number) => void }) => {
    const [percent, setPercent] = useState<number>(0);
    const tipAmount = Math.round(subtotal * (percent / 100));
    const totalWithTip = subtotal + tipAmount;

    return (
      <div className="bg-black/40 border border-gray-800 rounded-2xl p-4 mt-2">
        <div className="flex justify-between items-center mb-3">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{label}</span>
          <div className="flex gap-1">
            {[0, 10, 15, 20].map(p => (
              <button
                key={p}
                onClick={() => setPercent(p)}
                className={`w-10 h-8 rounded-lg text-[10px] font-black border transition-all ${percent === p ? 'bg-amber-500 text-black border-amber-500' : 'bg-transparent text-gray-600 border-gray-800 hover:border-gray-600'}`}
              >
                {p}%
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1 mb-4 border-t border-gray-800/50 pt-3">
          <div className="flex justify-between text-[10px] font-bold">
            <span className="text-gray-500 uppercase">Consumo (MXN):</span>
            <span className="text-gray-300">${subtotal.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-[10px] font-bold">
            <span className="text-amber-500/80 uppercase">Propina ({percent}%):</span>
            <span className="text-amber-500">${tipAmount.toLocaleString()}</span>
          </div>
          <div className="flex justify-between items-center pt-2 mt-1 border-t border-gray-800">
            <span className="text-xs text-white font-black uppercase tracking-tighter">Total MXN:</span>
            <span className="text-xl font-mono font-black text-green-500">${totalWithTip.toLocaleString()}</span>
          </div>
        </div>

        <button
          onClick={() => onConfirm(tipAmount)}
          className="w-full bg-green-600 text-black font-black py-3 rounded-xl uppercase text-[10px] tracking-widest hover:bg-green-500 active:scale-95 transition-all shadow-lg"
        >
          Confirmar Pago
        </button>
      </div>
    );
  };

  return (
    <div className="h-full">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {tables.map(table => (
          <button key={table.id} onClick={() => setSelectedTable(table)}
            className={`aspect-square rounded-2xl border-2 flex flex-col items-center justify-center gap-2 transition-all ${table.status === TableStatus.AVAILABLE ? 'border-gray-800 bg-[#111] text-gray-500' : 'border-amber-500 bg-amber-500/10 text-amber-500 shadow-lg'}`}>
            <span className="text-[10px] font-bold uppercase tracking-tighter">Mesa {table.id}</span>
            <span className="text-3xl font-cinzel font-bold">{table.id}</span>
            {table.status !== TableStatus.AVAILABLE && <span className="text-[10px] bg-amber-500 text-black px-2 rounded font-bold">${calculateTotal(table.order).toLocaleString()}</span>}
          </button>
        ))}
      </div>

      {selectedTable && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-0 md:p-4 bg-black/95 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#111] w-full h-full md:max-w-6xl md:max-h-[95vh] md:rounded-3xl flex flex-col lg:flex-row overflow-hidden border border-gray-800 shadow-2xl">

            <div className="flex-1 lg:w-1/2 p-4 md:p-6 overflow-y-auto border-r border-gray-800 flex flex-col">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-xl font-cinzel font-bold text-amber-500 uppercase">Mesa {selectedTable.id}</h2>
                  <div className="flex gap-4 mt-2">
                    <button onClick={() => setOrderTab('products')} className={`text-[10px] uppercase font-black pb-1 border-b-2 transition-all ${orderTab === 'products' ? 'border-amber-500 text-amber-500' : 'border-transparent text-gray-600'}`}>Productos</button>
                    <button onClick={() => setOrderTab('promos')} className={`text-[10px] uppercase font-black pb-1 border-b-2 transition-all ${orderTab === 'promos' ? 'border-amber-500 text-amber-500' : 'border-transparent text-gray-600'}`}>Promociones</button>
                  </div>
                </div>
                <button onClick={() => setSelectedTable(null)} className="text-gray-500 hover:text-white p-1"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {orderTab === 'products' ? (
                  inventory.map(p => (
                    <button key={p.id} onClick={() => handleAddItemToOrder(p)} disabled={p.units <= 0}
                      className="p-4 bg-[#1a1a1a] border border-gray-800 rounded-2xl text-left hover:border-amber-500 active:scale-95 transition-all disabled:opacity-50">
                      <p className="font-bold text-sm truncate">{p.name}</p>
                      <p className="text-xs text-green-500 font-mono font-bold">${p.sale_price}</p>
                      <p className={`text-[9px] mt-1 uppercase font-bold ${p.units <= p.min_stock ? 'text-red-500' : 'text-gray-600'}`}>Stock: {p.units}</p>
                    </button>
                  ))
                ) : (
                  promotions.map(p => (
                    <button key={p.id} onClick={() => handleAddItemToOrder(p)}
                      className="p-4 bg-[#1a1a1a] border border-amber-500/20 rounded-2xl text-left hover:border-amber-500 active:scale-95 transition-all">
                      <p className="font-bold text-sm truncate">{p.name}</p>
                      <p className="text-xs text-amber-500 font-mono font-bold">${p.price}</p>
                      <p className="text-[9px] text-gray-600 uppercase font-black mt-1">Combo</p>
                    </button>
                  ))
                )}
              </div>
            </div>

            <div className="lg:w-1/2 flex flex-col bg-[#0d0d0d]">
              <div className="p-4 md:p-6 flex-1 overflow-y-auto">
                <div className="mb-8">
                  <div className="flex justify-between items-center mb-4 border-b border-amber-500/20 pb-2">
                    <h3 className="text-amber-500 text-[10px] font-black uppercase tracking-[0.2em]">Comanda Actual</h3>
                    <button onClick={addSubject} className="bg-amber-500/10 text-amber-500 text-[10px] px-2 py-1 rounded border border-amber-500/20 font-bold uppercase hover:bg-amber-500 hover:text-black transition-colors">+ Añadir Sujeto</button>
                  </div>

                  <div className="space-y-2">
                    {selectedTable.order.length === 0 ? (
                      <p className="text-gray-600 italic text-center text-xs py-8">No hay consumos registrados aún.</p>
                    ) : (
                      selectedTable.order.map((item) => {
                        const assignedSubject = selectedTable.subjects.find(s => s.id === item.subjectId);
                        return (
                          <div key={item.id} className={`bg-[#151515] p-3 rounded-xl border flex justify-between items-center group ${item.isPromotion ? 'border-amber-500/30' : 'border-gray-800'}`}>
                            <div className="flex items-center gap-3">
                              <div className="flex flex-col">
                                <span className={`text-xs transition-all ${assignedSubject ? 'line-through opacity-30 italic' : 'text-gray-200 font-bold'}`}>
                                  {item.name}
                                </span>
                                {item.isPromotion && <span className="text-[7px] text-amber-500 uppercase font-black">Promoción Aplicada</span>}
                              </div>
                              {assignedSubject && (
                                <span className="text-[8px] bg-amber-500 text-black px-2 py-0.5 rounded-full font-black uppercase shadow-lg shadow-amber-500/10">
                                  {assignedSubject.name}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-3">
                              <select
                                value={item.subjectId}
                                onChange={(e) => assignItemToSubject(item.id, e.target.value)}
                                className="bg-black text-[10px] text-gray-400 border border-gray-800 rounded px-2 py-1 outline-none focus:border-amber-500 cursor-pointer"
                              >
                                <option value="0">General</option>
                                {selectedTable.subjects.map(s => (
                                  <option key={s.id} value={s.id}>{s.name}</option>
                                ))}
                              </select>
                              <span className="font-mono text-xs text-gray-500 w-12 text-right">${item.price}</span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                <div className="space-y-6">
                  {selectedTable.subjects.map(subject => {
                    const subTotal = calculateTotal(selectedTable.order, subject.id);
                    if (subTotal === 0) return null;
                    return (
                      <div key={subject.id} className="p-1 animate-slideIn">
                        <div className="flex items-center gap-2 mb-1 px-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div>
                          <span className="font-bold text-sm text-white">{subject.name}</span>
                        </div>
                        <TipPaymentBlock
                          subtotal={subTotal}
                          label={`Cuenta de ${subject.name}`}
                          onConfirm={(tip) => {
                            onCloseTable(selectedTable.id, subTotal, tip, subject.id);
                            setSelectedTable(null);
                          }}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-6 bg-[#111] border-t border-gray-800 shadow-2xl">
                <div className="flex justify-between items-end mb-4">
                  <div className="flex flex-col">
                    <span className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em]">Total General de Mesa</span>
                    <span className="text-[9px] text-amber-500/60 font-bold uppercase">Consumo total acumulado (MXN)</span>
                  </div>
                  <span className="text-4xl font-cinzel font-bold text-white tracking-tighter">${calculateTotal(selectedTable.order).toLocaleString()}</span>
                </div>

                {selectedTable.order.length > 0 && (
                  <TipPaymentBlock
                    subtotal={calculateTotal(selectedTable.order)}
                    label="Cierre Completo de Mesa"
                    onConfirm={(tip) => {
                      onCloseTable(selectedTable.id, calculateTotal(selectedTable.order), tip);
                      setSelectedTable(null);
                    }}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TablesGrid;
