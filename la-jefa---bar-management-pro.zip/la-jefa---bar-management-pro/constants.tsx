
import { Product, Table, TableStatus } from './types';

export const INITIAL_INVENTORY: Product[] = [
  { id: '1', name: 'Corona Extra', category: 'Cervezas', sale_price: 45, purchase_price: 22, units: 48, min_stock: 12 },
  { id: '2', name: 'Victoria', category: 'Cervezas', sale_price: 40, purchase_price: 18, units: 24, min_stock: 12 },
  { id: '3', name: 'Tequila Don Julio 70', category: 'Licores', sale_price: 180, purchase_price: 85, units: 10, min_stock: 3 },
  { id: '4', name: 'Margarita Clásica', category: 'Coctelería', sale_price: 120, purchase_price: 35, units: 100, min_stock: 20 },
  { id: '5', name: 'Nachos con Queso', category: 'Comida', sale_price: 150, purchase_price: 45, units: 30, min_stock: 5 },
];

export const TABLES_COUNT = 12;

export const INITIAL_TABLES: Table[] = Array.from({ length: TABLES_COUNT }, (_, i) => ({
  id: i + 1,
  status: TableStatus.AVAILABLE,
  subjects: [],
  order: [],
}));
