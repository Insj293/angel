
import React, { useState, useEffect, useCallback } from 'react';
import { InventoryItem, Table, TableStatus, Expense, DailyFinance, OrderItem, Promotion } from './types';
import { INITIAL_INVENTORY, INITIAL_TABLES } from './constants';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TablesGrid from './components/TablesGrid';
import InventoryManager from './components/InventoryManager';
import FinanceView from './components/FinanceView';
import PromotionsManager from './components/PromotionsManager';
import Login from './components/Login';
import { generateFullReportXML } from './utils/xmlHelper';
import { supabase } from './lib/supabase';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tables' | 'inventory' | 'finance' | 'promotions'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [resetKey, setResetKey] = useState(0); // Clave para forzar re-montaje de componentes

  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [tables, setTables] = useState<Table[]>(INITIAL_TABLES);
  const [promotions, setPromotions] = useState<Promotion[]>(() => {
    const saved = localStorage.getItem('la_jefa_promos');
    return saved ? JSON.parse(saved) : [];
  });

  const [finance, setFinance] = useState<DailyFinance>({
    openingCash: 0,
    expenses: [],
    date: new Date().toISOString().split('T')[0],
    totalTips: 0,
  });

  const [salesHistory, setSalesHistory] = useState<number>(0);
  const [financeId, setFinanceId] = useState<string | null>(null);

  const [newProd, setNewProd] = useState({ name: '', category: 'Refrescos', sale_price: 0, purchase_price: 0, units: 0, min_stock: 5 });

  // Supabase Data Fetching & Subscription
  useEffect(() => {
    const fetchData = async () => {
      // 1. Inventory
      const { data: invData } = await supabase.from('inventory').select('*').order('name');
      if (invData) setInventory(invData);

      // 2. Tables
      const { data: tablesData } = await supabase.from('tables').select('*').order('table_number');
      if (tablesData && tablesData.length > 0) {
        setTables(tablesData.map((t: any) => ({
          id: t.table_number,
          status: t.is_occupied ? TableStatus.OCCUPIED : TableStatus.AVAILABLE,
          order: t.comanda?.order || [],
          subjects: t.comanda?.subjects || []
        })));
      } else {
        // Initialize tables if empty
        const { error } = await supabase.from('tables').insert(
          INITIAL_TABLES.map(t => ({ table_number: t.id, is_occupied: false, comanda: { order: [], subjects: [] } }))
        );
        if (!error) {
          setTables(INITIAL_TABLES);
        }
      }

      // 3. Finance (Today)
      const today = new Date().toISOString().split('T')[0];
      const { data: finData } = await supabase.from('finances').select('*').eq('date', today).single();

      // Expenses (All time? Or just today? Prompt implies simple expense list. Let's load today's expenses)
      const { data: expData } = await supabase.from('expenses').select('*').gte('created_at', `${today}T00:00:00`).order('created_at', { ascending: false });

      if (finData) {
        setFinanceId(finData.id);
        setSalesHistory(finData.sales || 0);
        setFinance(prev => ({
          ...prev,
          openingCash: finData.initial_amount || 0,
          totalTips: finData.tips || 0,
          date: today,
          expenses: expData?.map((e: any) => ({
            id: e.id, description: e.description, amount: e.amount, category: e.category, timestamp: new Date(e.created_at)
          })) || []
        }));
      } else {
        // Create finance record for today if not exists
        const { data: newFin } = await supabase.from('finances').insert({ date: today }).select().single();
        if (newFin) {
          setFinanceId(newFin.id);
          setFinance(prev => ({ ...prev, date: today, expenses: [] }));
        }
      }
    };

    fetchData();

    // Realtime Subscriptions
    const sub = supabase.channel('main')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inventory' }, async (payload) => {
        if (payload.eventType === 'INSERT') setInventory(prev => [...prev, payload.new as InventoryItem]);
        if (payload.eventType === 'UPDATE') setInventory(prev => prev.map(i => i.id === payload.new.id ? payload.new as InventoryItem : i));
        if (payload.eventType === 'DELETE') setInventory(prev => prev.filter(i => i.id !== payload.old.id));
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tables' }, async (payload) => {
        if (payload.eventType === 'UPDATE') {
          const t = payload.new as any;
          setTables(prev => prev.map(pst => pst.id === t.table_number ? {
            id: t.table_number,
            status: t.is_occupied ? TableStatus.OCCUPIED : TableStatus.AVAILABLE,
            order: t.comanda?.order || [],
            subjects: t.comanda?.subjects || []
          } : pst));
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'finances' }, (payload) => {
        if (payload.new && (payload.new as any).date === new Date().toISOString().split('T')[0]) {
          const f = payload.new as any;
          setSalesHistory(f.sales);
          setFinance(prev => ({ ...prev, openingCash: f.initial_amount, totalTips: f.tips }));
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'expenses' }, async (payload) => {
        // Reload expenses to be safe or append
        const today = new Date().toISOString().split('T')[0];
        const { data: expData } = await supabase.from('expenses').select('*').gte('created_at', `${today}T00:00:00`).order('created_at', { ascending: false });
        if (expData) {
          setFinance(prev => ({
            ...prev, expenses: expData.map((e: any) => ({
              id: e.id, description: e.description, amount: e.amount, category: e.category, timestamp: new Date(e.created_at)
            }))
          }));
        }
      })
      .subscribe();

    return () => { supabase.removeChannel(sub); };
  }, []);

  // Persist Promotions Logic (Local Only)
  useEffect(() => {
    localStorage.setItem('la_jefa_promos', JSON.stringify(promotions));
  }, [promotions]);

  const performReset = useCallback(async () => {
    // Reset Logic
    if (financeId) {
      await supabase.from('finances').update({ sales: 0, tips: 0, initial_amount: 0 }).eq('id', financeId);
      // Normally we might delete expenses here too if requested, but for now just resetting state.
    }

    const { error: tError } = await supabase.from('tables').update({ is_occupied: false, comanda: { order: [], subjects: [] } }).neq('id', -1);

    // Also reset local state visually immediately
    setSalesHistory(0);
    setFinance(prev => ({
      openingCash: 0,
      expenses: [],
      date: new Date().toISOString().split('T')[0],
      totalTips: 0
    }));
    setTables(prev => prev.map(t => ({ ...t, status: TableStatus.AVAILABLE, order: [], subjects: [] })));

  }, [financeId]);

  const handleManualReset = () => {
    const confirmed = window.confirm(
      "⚠ REINICIAR TODA LA CAJA ⚠\n\n" +
      "Se reiniciarán Ventas, Propinas y Mesas en la base de datos.\n" +
      "El inventario NO se tocará.\n\n" +
      "¿Estás seguro?"
    );
    if (confirmed) {
      performReset();
      alert("Caja reiniciada con éxito.");
    }
  };

  const handleDownloadReport = () => {
    try {
      const totalExpenses = finance.expenses.reduce((a, b) => a + b.amount, 0);
      const balance = finance.openingCash + salesHistory + finance.totalTips - totalExpenses;
      const xml = generateFullReportXML(finance, salesHistory, totalExpenses, balance, inventory);

      const blob = new Blob([xml], { type: 'text/xml;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = url;
      link.setAttribute('download', `cierre-caja-${new Date().toISOString().split('T')[0]}.xml`);

      document.body.appendChild(link);
      link.click();

      setTimeout(() => {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        if (window.confirm("¿Deseas reiniciar la caja ahora que has bajado el reporte?")) {
          performReset();
        }
      }, 500);
    } catch (error) {
      console.error("Error al generar reporte:", error);
      alert("Error al generar el archivo XML.");
    }
  };

  if (!isLoggedIn) return <Login onLogin={() => setIsLoggedIn(true)} />;

  const handleAddItem = async (tableId: number, item: InventoryItem | Promotion) => {
    const isPromo = 'items' in item;

    if (isPromo) {
      const canAdd = item.items.every(comp => {
        const prod = inventory.find(p => p.id === comp.productId);
        // using 'units'
        return prod && prod.units >= comp.quantity;
      });
      if (!canAdd) { alert("Stock insuficiente."); return; }

      // Update stock one by one
      for (const comp of item.items) {
        const prod = inventory.find(p => p.id === comp.productId);
        if (prod) await supabase.from('inventory').update({ units: prod.units - comp.quantity }).eq('id', prod.id);
      }

      const newItem: OrderItem = { id: Math.random().toString(36).substr(2, 9), productId: 'PROMO', name: item.name, price: item.price, quantity: 1, subjectId: '0', isPromotion: true };

      const table = tables.find(t => t.id === tableId);
      if (table) {
        const newOrder = [...table.order, newItem];
        await supabase.from('tables').update({
          is_occupied: true,
          comanda: { order: newOrder, subjects: table.subjects }
        }).eq('table_number', tableId);
      }

    } else {
      // using 'units'
      if ((item as InventoryItem).units <= 0) { alert("Sin stock."); return; }

      await supabase.from('inventory').update({ units: (item as InventoryItem).units - 1 }).eq('id', (item as InventoryItem).id);

      const newItem: OrderItem = { id: Math.random().toString(36).substr(2, 9), productId: item.id, name: item.name, price: (item as InventoryItem).sale_price, quantity: 1, subjectId: '0' };

      const table = tables.find(t => t.id === tableId);
      if (table) {
        const newOrder = [...table.order, newItem];
        await supabase.from('tables').update({
          is_occupied: true,
          comanda: { order: newOrder, subjects: table.subjects }
        }).eq('table_number', tableId);
      }
    }
  };

  const handleUpdateTable = async (updatedTable: Table) => {
    // Sync with DB
    await supabase.from('tables').update({
      is_occupied: updatedTable.status !== TableStatus.AVAILABLE,
      comanda: { order: updatedTable.order, subjects: updatedTable.subjects }
    }).eq('table_number', updatedTable.id);
  };

  const handleCloseTable = async (tableId: number, subtotal: number, tip: number, subjectId?: string) => {
    // Update Sales and Tips in Finance
    const newSales = salesHistory + subtotal;
    const newTips = finance.totalTips + tip;

    if (financeId) {
      await supabase.from('finances').update({ sales: newSales, tips: newTips }).eq('id', financeId);
    }

    // Update Table
    const table = tables.find(t => t.id === tableId);
    if (table) {
      let newOrder = table.order;
      let newSubjects = table.subjects;
      let isOccupied = true;

      if (subjectId) {
        newOrder = table.order.filter(i => i.subjectId !== subjectId);
        newSubjects = table.subjects.filter(s => s.id !== subjectId);
        isOccupied = newOrder.length > 0;
      } else {
        newOrder = [];
        newSubjects = [];
        isOccupied = false;
      }

      await supabase.from('tables').update({
        is_occupied: isOccupied,
        comanda: { order: newOrder, subjects: newSubjects }
      }).eq('table_number', tableId);
    }
  };

  // Finance Handlers
  const handleUpdateOpeningCash = async (amount: number) => {
    if (financeId) {
      await supabase.from('finances').update({ initial_amount: amount }).eq('id', financeId);
    }
  };

  const handleAddExpense = async (exp: Expense) => {
    await supabase.from('expenses').insert({
      amount: exp.amount, description: exp.description, category: exp.category
    });
  };

  // Inventory Manager Handlers
  const handleUpdateProduct = async (p: InventoryItem) => {
    await supabase.from('inventory').update({
      name: p.name, category: p.category, purchase_price: p.purchase_price, sale_price: p.sale_price, units: p.units, min_stock: p.min_stock
    }).eq('id', p.id);
  };

  const handleDeleteProduct = async (id: string) => {
    await supabase.from('inventory').delete().eq('id', id);
  };

  // Helper to add new product
  const handleCreateProduct = async () => {
    if (!newProd.name) return;
    await supabase.from('inventory').insert({
      name: newProd.name,
      category: newProd.category,
      purchase_price: newProd.purchase_price,
      sale_price: newProd.sale_price,
      units: newProd.units,
      min_stock: newProd.min_stock
    });
    setShowAddProductModal(false);
    setNewProd({ name: '', category: 'Refrescos', sale_price: 0, purchase_price: 0, units: 0, min_stock: 5 });
  };

  return (
    <div className="flex h-screen bg-[#0a0a0a] text-gray-100 overflow-hidden">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lowStockCount={inventory.filter(p => p.units <= p.min_stock).length}
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
      />

      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 bg-[#1a1a1a] rounded-lg text-amber-500">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" /></svg>
            </button>
            <div>
              <h1 className="text-2xl font-cinzel font-bold text-amber-500 uppercase tracking-widest">La Jefa</h1>
              <span className="text-[8px] font-black uppercase tracking-tighter text-blue-500">● Gestión Activa (Supabase)</span>
            </div>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <button
              onClick={handleDownloadReport}
              className="flex-1 sm:flex-initial bg-amber-500 text-black px-4 py-3 rounded-xl font-black text-[10px] uppercase hover:bg-amber-400 transition-all shadow-lg active:scale-95"
            >
              Reporte XML
            </button>
            <button
              onClick={handleManualReset}
              className="flex-1 sm:flex-initial bg-red-600/20 text-red-500 border border-red-500/30 px-4 py-3 rounded-xl font-black text-[10px] uppercase hover:bg-red-600 hover:text-white transition-all shadow-lg active:scale-95"
            >
              Reiniciar Caja
            </button>
          </div>
        </header>

        <div className="max-w-7xl mx-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              key={`dash-${resetKey}`}
              inventory={inventory}
              sales={salesHistory}
              expenses={finance.expenses.reduce((acc, e) => acc + e.amount, 0)}
              lowStockCount={inventory.filter(p => p.units <= p.min_stock).length}
              tablesOccupied={tables.filter(t => t.status !== TableStatus.AVAILABLE).length}
              tips={finance.totalTips}
            />
          )}

          {activeTab === 'tables' && (
            <TablesGrid
              key={`tables-${resetKey}`}
              tables={tables}
              inventory={inventory}
              promotions={promotions}
              onUpdateTable={handleUpdateTable}
              onCloseTable={handleCloseTable}
              onAddItem={handleAddItem}
            />
          )}

          {activeTab === 'inventory' && (
            <div className="space-y-4">
              <div className="flex justify-end">
                <button onClick={() => setShowAddProductModal(true)} className="bg-amber-500 text-black px-4 py-2 rounded-xl font-bold text-[10px] uppercase hover:bg-amber-400">+ Nuevo Producto</button>
              </div>
              <InventoryManager
                inventory={inventory}
                onUpdateProduct={handleUpdateProduct}
                onDeleteProduct={handleDeleteProduct}
              />
            </div>
          )}

          {activeTab === 'promotions' && (
            <PromotionsManager
              promotions={promotions}
              inventory={inventory}
              onUpdatePromotion={(promo) => setPromotions(prev => prev.find(p => p.id === promo.id) ? prev.map(p => p.id === promo.id ? promo : p) : [...prev, promo])}
              onDeletePromotion={(id) => setPromotions(prev => prev.filter(p => p.id !== id))}
            />
          )}

          {activeTab === 'finance' && (
            <FinanceView
              key={`finance-${resetKey}`}
              finance={finance}
              sales={salesHistory}
              onUpdateOpeningCash={handleUpdateOpeningCash}
              onAddExpense={handleAddExpense}
            />
          )}
        </div>
      </main>

      {showAddProductModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <div className="bg-[#111] border border-gray-800 p-8 rounded-3xl max-w-md w-full shadow-2xl">
            <h2 className="text-xl font-cinzel font-bold text-amber-500 mb-6 uppercase tracking-widest text-center">Nuevo Producto</h2>
            <div className="space-y-4">
              <input type="text" placeholder="Nombre" className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none" value={newProd.name} onChange={e => setNewProd({ ...newProd, name: e.target.value })} />
              <select className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none" value={newProd.category} onChange={e => setNewProd({ ...newProd, category: e.target.value })}>
                <option value="Refrescos">Refrescos</option><option value="Cervezas">Cervezas</option><option value="Licores">Licores</option><option value="Coctelería">Coctelería</option><option value="Comida">Comida</option><option value="Otros">Otros</option>
              </select>
              <div className="grid grid-cols-2 gap-3">
                <input type="number" placeholder="Costo Compra" className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none font-mono" onChange={e => setNewProd({ ...newProd, purchase_price: parseFloat(e.target.value) || 0 })} />
                <input type="number" placeholder="Precio Venta" className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none font-mono" onChange={e => setNewProd({ ...newProd, sale_price: parseFloat(e.target.value) || 0 })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input type="number" placeholder="Unidades" className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none font-mono" onChange={e => setNewProd({ ...newProd, units: parseInt(e.target.value) || 0 })} />
                <input type="number" placeholder="Mínimo" className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-sm focus:border-amber-500 outline-none font-mono" value={newProd.min_stock} onChange={e => setNewProd({ ...newProd, min_stock: parseInt(e.target.value) || 0 })} />
              </div>
              <button onClick={handleCreateProduct} className="w-full bg-amber-500 text-black font-black py-4 rounded-xl uppercase text-xs mt-4 hover:bg-amber-400">Guardar</button>
              <button onClick={() => setShowAddProductModal(false)} className="w-full text-gray-500 text-[10px] uppercase font-bold py-2">Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
